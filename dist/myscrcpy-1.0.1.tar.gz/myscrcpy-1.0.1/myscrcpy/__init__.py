# -*- coding: utf-8 -*-
"""
    
    ~~~~~~~~~~~~~~~~~~
    

    Log:
         0.1.0 Me2sY
            创建

"""

__author__ = 'Me2sY'
__version__ = '0.1.0'

__all__ = []
