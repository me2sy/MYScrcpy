# MYScrcpy
## Me2sY

Mxx & ysY Scrcpy

使用adbutils,numpy,pyav,实现scrcpy视频及控制解析。

